
CREATE
    /*[ALGORITHM = {UNDEFINED | MERGE | TEMPTABLE}]
    [DEFINER = { user | CURRENT_USER }]
    [SQL SECURITY { DEFINER | INVOKER }]*/
    VIEW `xample`.`employe salary` 
    AS
SELECT employe.id, employe.name, employe.place, employe.phone, salary.salary FROM employe
INNER JOIN salary
ON employe.id=salary.employe

