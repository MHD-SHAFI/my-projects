function chek(){
    var a = document.getElementById('t1').value
    if (a % 2 == 0){
        document.getElementById('p1').innerHTML="even"
    }
    else{
        document.getElementById('p1').innerHTML="odd"
    }
}

function vote(){
    var b = document.getElementById('t2').value
    if (b > 17){
        document.getElementById('p2').innerHTML="Eligible for vote"
    }
    else{
        document.getElementById('p2').innerHTML="Not Eligible for vote"
    }
}