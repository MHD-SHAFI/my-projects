function show1(cc){
    var a=document.getElementById('aa').value;
    document.getElementById('aa').value = a+cc ;
}

function equalto(){
    var x = document.getElementById('aa').value;
    sum=eval(x)
    document.getElementById('aa').value=sum;

}

function cler(){
    document.getElementById('aa').value="";
}