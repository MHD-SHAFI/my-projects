let p1=0
let p2=4

document.getElementById("btn").addEventListener("click",setgrn)
function setgrn(){
    document.getElementById("btn").style.backgroundColor='red';
    p1++;
    p2--;
    document.getElementById("p1").innerHTML=p1
    document.getElementById("p2").innerHTML=p2
    document.getElementById("btn").disabled = true;
}

document.getElementById("btn1").addEventListener("click",setgrn1)
function setgrn1(){
    document.getElementById("btn1").style.backgroundColor='red';
    p1++;
    document.getElementById("p1").innerHTML=p1
    p2--;
    document.getElementById("p2").innerHTML=p2
    document.getElementById("btn1").disabled = true;
}

document.getElementById("btn2").addEventListener("click",setgrn1)
function setgrn2(){
    document.getElementById("btn2").style.backgroundColor='red';
    p1++;
    document.getElementById("p1").innerHTML=p1
    p2--;
    document.getElementById("p2").innerHTML=p2
    document.getElementById("btn2").disabled = true;
}

document.getElementById("btn3").addEventListener("click",setgrn1)
function setgrn3(){
    document.getElementById("btn3").style.backgroundColor='red';
    p1++;
    document.getElementById("p1").innerHTML=p1
    p2--;
    document.getElementById("p2").innerHTML=p2
    document.getElementById("btn3").disabled = true;
}

