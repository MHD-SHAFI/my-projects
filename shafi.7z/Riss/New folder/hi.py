print('')
a=int(input('enter a number'))
b=int(input('enter a number'))
c=a+b
print(c)