function txtfont(){
    document.getElementById('p1').style.fontFamily='Impact,Charcoal,sans-serif'
   }

function tprint(){
    var x = document.getElementById('t1').value
    document.getElementById('p2').innerHTML=x
}

function add(){
    var a = parseInt(document.getElementById('n1').value);
    var b = parseInt(document.getElementById('n2').value);
    var c = a + b;
    document.getElementById('p3').style.backgroundColor="green";
    document.getElementById('p3').style.fontFamily='Impact,Charcoal,sans-serif';
    document.getElementById('p3').style.color="blue";
    document.getElementById('p3').innerHTML = c ;
}
function sub(){
    var a = document.getElementById('n1').value;
    var b = document.getElementById('n2').value;
    var c = a - b ;
    document.getElementById('p3').style.backgroundColor="red";
    document.getElementById('p3').style.fontFamily='Impact,Charcoal,sans-serif';
    document.getElementById('p3').style.color="yellow";
    document.getElementById('p3').innerHTML = c ;
}
function div(){
    var a = document.getElementById('n1').value;
    var b = document.getElementById('n2').value;
    var c = a / b ;
    document.getElementById('p3').innerHTML = c ;
    document.getElementById('p3').style.backgroundColor="yellow";
    document.getElementById('p3').style.fontFamily='Impact,Charcoal,sans-serif';
    document.getElementById('p3').style.color="red";

}
function mult(){
    var a = document.getElementById('n1').value;
    var b = document.getElementById('n2').value;
    var c = a * b ;
    document.getElementById('p3').innerHTML = c ;
    document.getElementById('p3').style.backgroundColor="blue";
    document.getElementById('p3').style.fontFamily='Impact,Charcoal,sans-serif';
    document.getElementById('p3').style.color="green";

}