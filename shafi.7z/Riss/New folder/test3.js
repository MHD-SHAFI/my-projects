function ck(){
    document.getElementById('p2').src='C:\Users\HP\Riss\images\thor.jpg'
}