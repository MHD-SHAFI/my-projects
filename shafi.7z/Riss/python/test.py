


# class vehicle:
#     def __init__(self,vn,vt):
#         self.__vehicleName=vn
#         self.vehicleType=vt

#     def display(self):
#         print(self.__vehicleName,self.vehicleType)
#                                                           encapsulation
#     def getvehicleName(self):
#         print(self.__vehicleName)

#     def setvehicleName(self,nm):
#         self.__vehicleName=nm

    
# vh1=vehicle("suuki","4W")
# vh1.display()
# vh1.getvehicleName()
# vh1.setvehicleName("toyota")
# vh1.getvehicleName()
# vh1.display()

        


# from abc import ABC
# class bankbal(ABC):
#     def __init__(self,bal=0):
#         self.balance=bal

#     def deposit(self,amt):
#         pass
#                                       data abstraction
#     def withdrawal(self,amt):
#         pass

#     def checkbal(self):
#         print(self.balance)

# class savings(bankbal):
#     def deposit(self, amt):
#         self.balance+=amt
#         print(self.balance)

#     def withdrawal(self, amt):
#         if self.balance >= amt:
#             self.balance-=amt
#             print(self.balance)
#         else:
#             print("insufficient balance")

# save=savings(1000)
# save.deposit(2000)
# save.checkbal()
# save.withdrawal(250)


# class vehicle:
#     def __init__(self,vn,vt):
#         self.vehicleName=vn
#         self.vehicleType=vt

#     def move(self):
#         print("moving")

#                                           polymorphism
# class car:
#     def __init__(self,nm,pl):
#         self.name=nm
#         self.place=pl

#     def move(self):
#         print("drive")


# class airoplane:
#     def __init__(self,tn,al):
#         self.town=tn
#         self.alive=al

#     def move(self):
#         print("flying")

# hey=vehicle("bike","2W")
# you=car("lamborgini","uk")
# yes=airoplane("chicago","yes")

# for i in(hey,you,yes):
#     i.move()


# class sum:
#     def add(self,a,b,c=0):
#         return a+b+c
#                                   method overloading
# guy=sum()
# print(guy.add(3,4))
# print(guy.add(5,6,9))


# class vehicle:
#     def sound(self):
#         print("drrrrrr")
#                                   method overriding
# class car(vehicle):
#     def sound(self):
#         print("grrrrr")
# toyota=car()
# toyota.sound()


# class parent:
#     def __init__(self,fn,ln,ag):
#         self.firstname=fn
#         self.lastname=ln
#         self.age=ag
#                                           inheritence
# class child(parent):
#     def __init__(self, fn, ln, ag):
#         super().__init__(fn, ln, ag)
        
# u=child("suru","baba",34)
# v=child("eudu","koku",23)
# w=child("eheh","kfjg",58)

# print(u.firstname,u.lastname,u.age)
# print(v.firstname,v.lastname,v.age)
# print(w.firstname,w.lastname,w.age)




# class person:
#     def __init__(self,nm,gndr,ag):
#         self.name=nm
#         self.gender=gndr
#         self.age=ag
#                                              this is class and object demo/sample
#     def hobby(self):
#         print("dancing is the hobby of,",self.name)   
# y=person("namu","trans",55)  
# n=person("shaz","male",23)
# z=person("kai","female",35)
# print(y.name,y.age,y.gender)
# print(n.name,n.age,n.gender)
# print(z.name,z.age,z.gender)
# y.hobby()
# n.hobby()
# z.hobby()





# def star():
#     n=4
#     for i in range (n):
#         print(' ' * (n - i - 1) + '*' * (i + 1)) 
# star()


# def calc():
#     print("enter a number from the options\n1.addition\n2.subtraction\n3.multiplication\n4.division\n5.exit")
#     a=int(input("enter option "))
#     if a == 1:
#         print("enter the numbers to be operated")
#         b=int(input("enter no.1 "))
#         c=int(input("enter no.2 "))
#         print(b+c)
#     if a == 2:
#         print("enter the numbers to be operated")
#         b=int(input("enter no.1 "))
#         c=int(input("enter no.2 "))
#         print(b-c)
#     if a == 3:
#         print("enter the numbers to be operated")
#         b=int(input("enter no.1 "))
#         c=int(input("enter no.2 "))
#         print(b*c)
#     if a == 4:
#         print("enter the numbers to be operated")
#         b=int(input("enter no.1 "))
#         c=int(input("enter no.2 "))
#         print(b/c)
#     if a == 5:
#         return exit()
#     return calc()
# calc()


# def sumofn(n):
#     b=0
#     for i in range(1,n+1):
#         b=b+i
#     print(b)
#     return b
# a=int(input("enter the limit  "))
# sumofn(a)


# def listlg():
#     a=[6,3,57,12,8,4,9]
#     b=0
#     for i in a:
#         if i > b:
#             b=i
#     print(b)
# listlg()


# def febi():
#     a=int(input("enter a number"))
#     e=0
#     i=1
#     while i <= a:
#         f=e+i
#         print(f)
#         e=e+1
#         i=i+1
# febi()

# def pali():
#     a=input("enter a number  ")
#     c="".join(reversed(a))
#     print(c)
#     if a == c:
#         print("its palindrome")
#     else:
#         print("not palindrome")
# pali()


# def prime():
#     a = int(input("enter a number  "))
#     if a >1:
#         for d in range(2,a):
#             if a % d == 0:
#                 print("not prime")
#                 break
#         else:
#             print("prime")
#     else:
#         print("not prime")
# prime()


# def lgno():
#     a=int(input("enter no.1 "))
#     b=int(input("enter no.2 "))
#     c=int(input("enter no.3 "))
#     if a > b and a > c:
#         print(a,"is greater")
#     elif b > c and b > a:
#         print(b,"is graeter")
#     else:
#         print(c,"is larger")
# lgno()

# def factor(a):
#     for i in range(1,a+1):
#         f=i*a
#         print(f,i,a)
#     print(f)
# factor(5)

# def sum():
#     print(2+5)
# sum()

# def day(a,b):
#     print(a+b)
# day(5,5)    

# def getpy():
#     return 3.14
# a=getpy()
# print("pi value is:",a)

# def soman(a,b):
#     return a*b
# d=soman(5,6)
# print(d)


# a = int(input("enter a number "))
# b = a
# s = 0
# while b > 0:
#     r=b % 10
#     s+=r**3
#     b//=10
    
# if a==s:
#     print("its armstrong no.")
# else:
#     print("its not armstrong")



# a=input("enter a string  ")
# c="".join(reversed(a))

# print(c)

# if a == c:
#     print("its palindrome")
# else:
#     print("not palindrome")
    

# a = int(input("enter a number  "))
# if a >1:
#     for d in range(2,a):
#         if a % d == 0:
#             print("not prime")
#             break
#     else:
#         print("prime")
# else:
#     print("not prime")
    

# a=int(input("enter no.1"))
# b=int(input("enter no.2"))
# c=int(input("enter no.3"))
# if a > b and a > c:
#     print(a," is larger")
# elif b > a and b > c:
#     print(b," is larger")
# else:
#     print(c," is larger")

# if a>100:
#     print("not allowed")
# elif a>90:
#     print("grade A")
# elif a>80:
#     print("grade B")
# elif a>70:
#     print("grade C")
# elif a>60:
#     print("grade D")
# elif a>50:
#     print("grade E")
# else:
#     print("grade F")